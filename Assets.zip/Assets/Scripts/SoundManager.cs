﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    static AudioClip Explosion, Lose, Pew;
    public AudioClip explosion, lose, pew;
    static AudioSource AudioSource;

    void Awake()
    {
        AudioSource = GetComponent<AudioSource>();
        Explosion = explosion;
        Lose = lose;
        Pew = pew;
    }

    public static void Explode()
    {
        AudioSource.PlayOneShot(Explosion);       
    }
    public static void Dead()
    {
        AudioSource.PlayOneShot(Lose);
    }
    public static void LiftOf()
    {    
        AudioSource.PlayOneShot(Pew);
    }
}
