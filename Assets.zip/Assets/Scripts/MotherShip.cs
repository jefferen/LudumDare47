﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MotherShip : MonoBehaviour
{
    void OnCollisionEnter2D(Collision2D other) // display death and such and slight delay
    {
        Player.Explode();
        Player.DontMove();
        Debug.Log("Yooo");
        MenuManager.Victory();
        Debug.Log("Yooo2");
    }
}
