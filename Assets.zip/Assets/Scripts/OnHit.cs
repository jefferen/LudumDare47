﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnHit : MonoBehaviour
{
    public bool destroy;

    void OnCollisionEnter2D(Collision2D other) // display death and such and slight delay
    {
        if (destroy) Player.Explode();
        SoundManager.Dead();
        Player.DontMove();
        Player.HidePlayerSprite(false);
        Invoke("PlacePlayer",1);    
    }

    void PlacePlayer()
    {
        Player.PlacePlayer();
        Player.HidePlayerSprite(true);
    }
}
