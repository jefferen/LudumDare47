﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public struct Wings
    {
        public Transform wingL, wingR;

        public Wings(Transform l, Transform r)
        {
            wingL = l;
            wingR = r;
        }
    }
    static SpriteRenderer mySprite;
    static GameObject Trail;
    public GameObject leftWing, rightWing, explosion, trail;
    static GameObject LookAtObject, Explosion;
    static Transform myTransform;                     // can only do this because there will only ever be one player and I'm never destroying the player
    public float MoveSpeed;
    static float moveSpeed;
    static Rigidbody2D rb;
    static bool shouldMove = true;
    static bool clockWise;
    static Vector2 startPos;
    static Quaternion startRot;
    static Wings myWings;

    void Awake()
    {
        Cache();
        rb.velocity = transform.up * moveSpeed;
    }

    void Cache()
    {
        Trail = trail;
        mySprite = GetComponent<SpriteRenderer>();
        Explosion = explosion;
        moveSpeed = MoveSpeed;
        startPos = transform.position;
        startRot = transform.rotation;
        rb = GetComponent<Rigidbody2D>();
        myTransform = transform;
        myWings = new Wings(leftWing.transform, rightWing.transform);
    }

    public void Update()//another script that looks at mouse pos where the sprite rotates to that direction, player remains in actuality in the same dir it travels
    {
        if(LookAtObject)
        {
            transform.right = LookAtObject.transform.position - transform.position;
            if (!clockWise) transform.right *= -1;
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            Move();                    
        }

        if (Input.GetKeyDown(KeyCode.R))
        {
            PlacePlayer();
        }

        if (!shouldMove)
        {
            rb.velocity = Vector2.zero;
        }
    }

    public static void Move()
    {
        SoundManager.LiftOf();
        myTransform.SetParent(null);
        OrbitAroundObject.hasorbit = false;
        LookAtObject = null;
        shouldMove = true;
        rb.velocity = myTransform.up * moveSpeed;
        rb.angularVelocity = 0;
        rb.freezeRotation = true;
    }

    public static void DontMove()
    {
        shouldMove = false;
    }

    public static bool ClockWise(bool b)
    {
        clockWise = b;
        return b;
    }

    public static void FaceOrbitTarget(GameObject g)
    {
        LookAtObject = g;
    }

    public static void PlacePlayer()
    {
        myTransform.SetPositionAndRotation(startPos, startRot);
        Move();
    }

    public static void HidePlayerSprite(bool b)
    {
        MenuManager.UndisplayVictory();
        mySprite.enabled = b;
        Trail.SetActive(b);
    }

    public static void Explode()
    {
        SoundManager.Explode();
        Explosion.transform.position = myTransform.position;
        Explosion.SetActive(true);
    }

    public Wings PlayerWings()
    {
        return myWings;
    }
}