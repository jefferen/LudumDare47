﻿using UnityEngine;

public class MenuManager : MonoBehaviour
{
    GameObject menu;
    public GameObject youWon;
    static GameObject YouWon;

    void Awake()
    {
        YouWon = youWon;
        menu = gameObject;
        UndisplayVictory();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.D)) CloseMenu();
        if (Input.GetKeyDown(KeyCode.Escape) && Application.platform != RuntimePlatform.WebGLPlayer) Application.Quit();
    }

    void CloseMenu()
    {
        menu.SetActive(!menu.activeInHierarchy);  // set menu to what ever it is not
    }

    public static void Victory()
    {
        YouWon.SetActive(true);
    }

    public static void UndisplayVictory()
    {
        YouWon.SetActive(false);
    }
}