﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrbitAroundObject : MonoBehaviour
{
    public Player myPlayer;
    public string tag;
    GameObject center;
    public float orbitSpeed;
    public static bool hasorbit = false;
    bool orbitClock;

    void Awake()
    {
        center = transform.GetChild(0).gameObject;
    }

    void Update()
    {
         if (hasorbit) Orbit();
    }

    void OnCollisionEnter2D(Collision2D other) 
    {
        if (other.gameObject.CompareTag(tag)) // make player a child of center and rotate center, remove player as child when wanting to free itself from orbit
        {
            other.gameObject.transform.parent = center.transform;
            Player.DontMove();
            Player.FaceOrbitTarget(gameObject);
            OrbitDir();
            hasorbit = true;
        }
    }

    void OrbitDir() 
    {
        float dist1, dist2;
        Player.Wings wing = myPlayer.PlayerWings();
        dist1 = Vector2.Distance(center.transform.position, wing.wingL.position); // left would be counter clock
        dist2 = Vector2.Distance(center.transform.position, wing.wingR.position); // right would be clockwise
        if (dist1 <= dist2) orbitClock = Player.ClockWise(false);   // now this is some odd code I'm doing!!
        else orbitClock = Player.ClockWise(true);
    }

    void Orbit() // go clockwise, + should be clockwise I believe
    {
        if(orbitClock) center.transform.Rotate(Vector3.forward, -orbitSpeed);
        else center.transform.Rotate(Vector3.forward, +orbitSpeed);
    }
}
