﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveBetweenPoints : MonoBehaviour
{
    [Range(0.1f,0.7f)]
    public float moveSpeed;
    public GameObject pos1, pos2;
    Vector2 p1, p2;
    float index = 0;

    void Awake()
    {
        p1 = pos1.transform.position;
        p2 = pos2.transform.position;
    }

    void Update()
    {
        Lerping();
    }

    void Lerping()
    {
        index = Mathf.PingPong(Time.time * moveSpeed, 1);
        transform.position = Vector2.Lerp(p1, p2, index);
    }
}
